package co.com.elbaiven.category;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

// TODO: This file is just an example, you should delete or modify it
public interface CategoryReactiveRepository extends ReactiveCrudRepository<CategoryModel, Integer> {

}
