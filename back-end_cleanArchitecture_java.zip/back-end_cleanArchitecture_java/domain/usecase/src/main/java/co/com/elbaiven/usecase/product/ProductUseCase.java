package co.com.elbaiven.usecase.product;

import lombok.RequiredArgsConstructor;
@RequiredArgsConstructor
public class ProductUseCase {
}
